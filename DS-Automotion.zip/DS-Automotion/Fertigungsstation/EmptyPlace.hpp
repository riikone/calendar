#include "Observer.hpp"

using namespace std;

class EmptyPlace : public ISubject{
    private:
        IObserver* observer;
        bool emptyPlaceSensor;
        int count;
        
    public:
        EmptyPlace(){ emptyPlaceSensor = true; count = 0;};
        void attach(IObserver* observer){ this->observer = observer; };
        void dettach(){ delete this->observer; };
        void virtual noify() { this->observer->onEmptyPlaceSensorChanged(); };

        //Getter and Setter
        void setEmptyPlaceSensor(bool value);
        bool getEmptyPlaceSensor() { return this->emptyPlaceSensor; };
};

void EmptyPlace::setEmptyPlaceSensor(bool value){
    this->emptyPlaceSensor = value; 
    if(value = true){
        count++;
    } else {

    }
    notify();
}