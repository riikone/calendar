#ifndef EMPTY_PLACE_HPP
#define EMPTY_PLACE_HPP

#include "Observer.hpp"

using namespace std;

class EmptyPlace : public ISubject{
    private:
        IObserver* observer;
        bool emptyPlaceSensor;
        int bottleId;
        
    public:
        EmptyPlace(){ emptyPlaceSensor = true; bottleId = 0;};
        void attach(IObserver* pObserver) override;
        void dettach() override;
        void notify() override;

        //Getter and Setter
        void setEmptyPlaceSensor(bool pValue);
        bool getEmptyPlaceSensor() { return this->emptyPlaceSensor; };
};

void EmptyPlace::attach(IObserver* pObserver){
    this->observer = pObserver;
}

void EmptyPlace::dettach(){
    delete this->observer; 
}

void EmptyPlace::notify(){
    this->observer->onEmptyPlaceSensorChanged();
}

void EmptyPlace::setEmptyPlaceSensor(bool pValue){
    if(pValue){
        cout << "Leergut ist besetzt!" << endl;
    } else {
        cout << "Leergut ist leer!" << endl;
    }
    this->emptyPlaceSensor = pValue; 
    this->notify();
}

#endif //EMPTY_PLACE_HPP