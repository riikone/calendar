#ifndef CONTROL_SYSTEM_OBSERVER_HPP
#define CONTROL_SYSTEM_OBSERVER_HPP

#include <vector>
#include "Subject.hpp"
#include "Observer.hpp"
#include "Machine.hpp"

using namespace std;

class ControlSystemObserver : public IObserver{
    private:
        ControlSystem* contolSystem;

    public:
        ControlSystemObserver(ControlSystem* pControlSystem){ this->contolSystem = pControlSystem; };
        void onEmptyPlaceSensorChanged() override;
        void onFullPlaceSensorChanged() override;
        void onMachineSensorChanged(Machine& pMachine) override;

         ControlSystem* getControlSystem(){ return contolSystem; };
};

void ControlSystemObserver::onEmptyPlaceSensorChanged(){
    if(this->getControlSystem()->getEmptyPlace()->getEmptyPlaceSensor() == true){
        this->getControlSystem()->addBottleCounter();
        if(this->getControlSystem()->getBottleCounter() < 50){
            cout << "Die Flasche " << this->getControlSystem()->getBottleCounter() << " ist in Progress!" << endl;
            for (int i = 0; i < this->getControlSystem()->getMachineSize(); i++){
                Machine& machine = this->getControlSystem()->getMachine(i);
                if(machine.getStatus() == 1){
                    machine.setBottleId(this->getControlSystem()->getBottleCounter());
                    machine.setStatus(2);
                    this->getControlSystem()->getEmptyPlace()->setEmptyPlaceSensor(true);
                    break;
                }
            }
        } else {
            cout << "Programm Ende!!!" << endl;
            this->getControlSystem()->dettach();
        }
    } else {
        this->getControlSystem()->getEmptyPlace()->setEmptyPlaceSensor(true);
    }
}

void ControlSystemObserver::onFullPlaceSensorChanged(){
    if(this->getControlSystem()->getFullPlace()->getFullPlaceSensor() == true){
        for (int i = 0; i < this->getControlSystem()->getMachineSize(); i++){
            Machine& machine = this->getControlSystem()->getMachine(i);
            if(machine.getStatus() == 3){
                machine.setStatus(1);
                this->getControlSystem()->getFullPlace()->setFullPlaceSensor(false);
                break;
            }
        }
    } else {
        if(this->getControlSystem()->getFullPlace()->getBottleId() > 0){
            cout << "Die Flasche " << this->getControlSystem()->getFullPlace()->getBottleId() << " wird von dem Vollgutplatz abgeholt!" << endl;
            this->getControlSystem()->getFullPlace()->setBottleId(-1);
            this->getControlSystem()->getFullPlace()->setFullPlaceSensor(true);
        } else {
            this->getControlSystem()->getFullPlace()->setFullPlaceSensor(true);
        }
    }
}

void ControlSystemObserver::onMachineSensorChanged(Machine& pMachine){
    if(pMachine.getStatus() == 2){
        if(this->getControlSystem()->getFullPlace()->getFullPlaceSensor() == true){
            cout << "Die Flasche " << pMachine.getBottleId() << " wird auf dem Vollgutplatz gestellt!" << endl;
            this->getControlSystem()->getFullPlace()->setBottleId(pMachine.getBottleId());
            pMachine.setStatus(1);
            this->getControlSystem()->getFullPlace()->setFullPlaceSensor(false);
        } else {
            cout << "Die Flasche " << pMachine.getBottleId() << " muss fuer den Vollgutplatz warten!" << endl;
            pMachine.setStatus(3);        
        }
    } else if(pMachine.getStatus() == 3){
        if(this->getControlSystem()->getFullPlace()->getFullPlaceSensor() == true){
            cout << "Die Flasche " << pMachine.getBottleId() << " wird auf dem Vollgutplatz gestellt!" << endl;
            this->getControlSystem()->getFullPlace()->setBottleId(pMachine.getBottleId());
            pMachine.setStatus(1);
            this->getControlSystem()->getFullPlace()->setFullPlaceSensor(false);
        }
    }   
}

#endif //CONTROL_SYSTEM_OBSERVER_HPP