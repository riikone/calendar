
#include <vector>;
#include "Subject.hpp";
#include "Observer.hpp";
#include "EmptyPlace.hpp";
#include "FullPlace.hpp";
#include "Machine.hpp";

using namespace std;

class ControlSystemObserver : public IObserver{
    private:
        EmptyPlace* emptyPlace;
        FullPlace* fullPlace;
        vector<Machine*> machines;

    public:
        void onEmptyPlaceSensorChanged();
        void onFullPlaceSensorChanged();
        void onMachineSensorChanged(Machine& machine);
};

void ControlSystemObserver::onEmptyPlaceSensorChanged(){
    if(this->emptyPlace->getEmptyPlaceSensor() == true){
        for (int i = 0; i < this->machines.size(); i++){
            if(this->machines[i]->getStatus() == 1){
                this->machines[i]->setStatus(2);
                this->emptyPlace->setEmptyPlaceSensor(false);
                break;
            }
        }
    } else {
        this->emptyPlace->setEmptyPlaceSensor(true);
    }
}

void ControlSystemObserver::onFullPlaceSensorChanged(){
    if(this->fullPlace->getFullPlaceSensor() == true){
        for (int i = 0; i < this->machines.size(); i++){
            if(this->machines[i]->getStatus() == 1){
                this->machines[i]->setStatus(2);
                this->fullPlace->setFullPlaceSensor(false);
                break;
            }
        }
    } else {
        this->fullPlace->setFullPlaceSensor(true);
    }
}

void ControlSystemObserver::onMachineSensorChanged(Machine& machine){
    if(this->fullPlace->getFullPlaceSensor() == true){
        if(machine.getStatus() == 2){
            machine.setStatus(3);
        }
    } else {
        this->fullPlace->setFullPlaceSensor(true);
    }
}
