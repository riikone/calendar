#ifndef FULL_PLACE_HPP
#define FULL_PLACE_HPP

#include "Observer.hpp"

using namespace std;

class FullPlace : public ISubject{
    private:
        IObserver* observer;
        bool fullPlaceSensor;
        int bottleId;

    public:
        FullPlace(){fullPlaceSensor = true;bottleId = 0;};
        void attach(IObserver* pObserver) override;
        void dettach() override;
        void notify() override;

        //Getter and Setter
        void setFullPlaceSensor(bool pValue);
        bool getFullPlaceSensor() { return this->fullPlaceSensor; };
        void setBottleId(int pId){ this->bottleId = pId; };
        int  getBottleId(){ return bottleId; };
};

void FullPlace::attach(IObserver* pObserver){
    this->observer = pObserver;
}

void FullPlace::dettach(){
    delete this->observer; 
}

void FullPlace::notify(){
    this->observer->onFullPlaceSensorChanged();
}

void FullPlace::setFullPlaceSensor(bool pValue){
    if(pValue){
        cout << "Vollgut ist leer!" << endl;
    } else {
        cout << "Vollgut ist besetzt!" << endl;
    }
    this->fullPlaceSensor = pValue; 
    notify();
}

#endif //FULL_PLACE_HPP