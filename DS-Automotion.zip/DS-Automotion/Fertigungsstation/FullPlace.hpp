#include "Observer.hpp"

using namespace std;

class FullPlace : public ISubject{
    private:
        IObserver* observer;
        bool fullPlaceSensor;

    public:
        void virtual attach(IObserver* observer){ this->observer = observer; };
        void virtual dettach(){ delete this->observer; };
        void virtual noify() { this->observer->onFullPlaceSensorChanged(); };

        //Getter and Setter
        void setFullPlaceSensor(bool value){ this->fullPlaceSensor = value; notify(); };
        bool getFullPlaceSensor() { return this->fullPlaceSensor; };
};
