#include "Observer.hpp";
#include <string>;

using namespace std;

class Machine : public ISubject{
    private:
        IObserver* observer;
        int status;
        string name;

    public:
        void attach(IObserver* observer){ this->observer = observer; };
        void dettach(){ delete this->observer; };
        void virtual noify() { this->observer->onMachineSensorChanged(); };

        //Getter and Setter
        int getStatus() { return this->status; };
        void setStatus(int value) { this->status = value; notify();};
        string getName() { return this->name; };
        void setName(string name) { this->name = name; };

        //string startTimer(unsigned short int seconds, callback);
        void killTimer(string id);
};


