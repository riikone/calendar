#ifndef MACHINE_HPP
#define MACHINE_HPP

#include "Observer.hpp"
#include "Timer.hpp"
#include <string>

using namespace std;

class Machine : public ISubject{
    private:
        IObserver* observer;
        int status;
        string name;
        int bottleId;

    public:
        void attach(IObserver* pObserver) override;
        void dettach() override;
        void notify() override;

        //Getter and Setter
        int getStatus() { return this->status; };
        void setStatus(int pValue);
        string getName() { return this->name; };
        void setName(string pName) { this->name = pName; };
        int getBottleId(){ return this->bottleId; };
        void setBottleId(int pId);

        Machine(string pName);

        //string startTimer(unsigned short int seconds, callback);
        void killTimer(string id);
};

void Machine::attach(IObserver* pObserver){
    this->observer = pObserver;
}

void Machine::dettach(){
    delete this->observer; 
}

void Machine::notify(){
    this->observer->onMachineSensorChanged(*this);
}

Machine::Machine(string pName){
    this->name = pName;
    this->bottleId = 0;
    this->status = 1;
}

void Machine::setStatus(int pValue){
    this->status = pValue; 
    switch (pValue)
    {
        case 1 :
            cout << name << " ist bereit!" << endl;
            break;
        case 2 :
            cout << name << " ist in Progress!" << endl;
            break;
        case 3 :
            cout << name << " wartet auf Vollgutplatz!" << endl;
            break;
        default:
            break;
    }
    /* 
    if(pValue == 2){
        Timer t2;

        t2.setFunc([&](){
            notify();
        })
            ->setInterval(1000)
            ->start();
    }
    */
    notify();
}

void Machine::setBottleId(int pId){
    this->bottleId = pId;
    cout << "Die Flasche " << pId << " wird in der Maschine " << name << " vorbereitet!" << endl;
}

#endif //MACHINE_HPP