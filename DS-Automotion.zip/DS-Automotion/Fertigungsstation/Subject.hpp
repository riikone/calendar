#ifndef SUBJECT_HPP
#define SUBJECT_HPP

class ISubject {
    public:
        virtual void attach(class IObserver* pObserver) = 0;
        virtual void dettach() = 0;
        virtual void notify() = 0;
};

#endif //SUBJECT_HPP