#ifndef OBSERVER_PATTERN_SUBJECT_HPP
#define OBSERVER_PATTERN_SUBJECT_HPP

class ISubject {
    public:
        virtual void attach(class IObserver* observer) = 0;
        virtual void dettach() = 0;
        virtual void notify() = 0;
        
};

#endif //OBSERVER_PATTERN_SUBJECT_HPP