#include <iostream>
#include "Subject.hpp"
#include "Observer.hpp"
#include "EmptyPlace.hpp"
#include "FullPlace.hpp"

#include <vector>


using namespace std;

int main(){

}