#ifndef OBSERVER_PATTERN_HPP
#define OBSERVER_PATTERN_HPP

class IObserver {
    public:
        virtual void onEmptyPlaceSensorChanged() = 0;
        virtual void onFullPlaceSensorChanged() = 0;
        virtual void onMachineSensorChanged() = 0;
};

#endif //OBSERVER_PATTERN_HPP
