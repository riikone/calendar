#include "ControlSystem.hpp"

class Simulator : public ControlSystem{

};