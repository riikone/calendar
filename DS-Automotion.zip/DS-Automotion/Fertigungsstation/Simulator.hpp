#ifndef SIMULATOR_HPP
#define SIMULATOR_HPP

#include "Subject.hpp"
#include "Observer.hpp"
#include "EmptyPlace.hpp"
#include "FullPlace.hpp"
#include "ControlSystem.hpp"
#include "ControlSystemObserver.hpp"

class Simulator : public ControlSystem{
    private:
        int testRuns;
        ControlSystem* controlSystem;
        ControlSystemObserver* observer;
    public:
        void initTest();
        void runTest();
};

#endif //SIMULATOR_HPP

void Simulator::initTest(){
    testRuns = 0;
    EmptyPlace* emptyPlace = new EmptyPlace();
    FullPlace* fullPlace = new FullPlace();
    Machine* machine1 = new Machine("Machine1");
    Machine* machine2 = new Machine("Machine2");
    Machine* machine3 = new Machine("Machine3");
    controlSystem = new ControlSystem(emptyPlace, fullPlace);
    controlSystem->addMachine(machine1);
    controlSystem->addMachine(machine2);
    controlSystem->addMachine(machine3);
    observer = new ControlSystemObserver(controlSystem);
    controlSystem->attach(observer);
    emptyPlace->attach(observer);
    fullPlace->attach(observer);
    machine1->attach(observer);
    machine2->attach(observer);
    machine3->attach(observer);
}

void Simulator::runTest(){
    controlSystem->getEmptyPlace()->setEmptyPlaceSensor(true);
}