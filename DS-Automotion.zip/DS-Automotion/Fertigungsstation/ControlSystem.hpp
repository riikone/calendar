#include <vector>;
#include "Observer.hpp";
#include "Subject.hpp";
#include "EmptyPlace.hpp";
#include "FullPlace.hpp";
#include "Machine.hpp";

using namespace std;

class ControlSystem : public ISubject {
    private:
        EmptyPlace* emptyPlace;
        FullPlace* fullPlace;
        vector<class Machine*> listMachine;
        IObserver* observer;

    public:
        ControlSystem(EmptyPlace* emptyPlace, FullPlace* fullPlace);
        void attach(IObserver* observer){ this->observer = observer; };
        void dettach(){ delete this->observer; };
        void virtual noify(){ this->observer->onMachineSensorChanged(); };
        void addMachine(Machine* machine){ this->listMachine.push_back(machine); };
};

ControlSystem::ControlSystem(EmptyPlace* emptyPlace, FullPlace* fullPlace){
    this->emptyPlace = emptyPlace;
    this->fullPlace = fullPlace;
}