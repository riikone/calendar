#ifndef CONTROL_SYSTEM_HPP
#define CONTROL_SYSTEM_HPP

#include <vector>
#include "Observer.hpp"
#include "Subject.hpp"

using namespace std;

class ControlSystem : public ISubject {
    private:
        EmptyPlace* emptyPlace;
        FullPlace* fullPlace;
        vector<class Machine*> listMachine;
        IObserver* observer;
        int bottleCounter;

    public:
        ControlSystem():ISubject(){}
        ControlSystem(EmptyPlace* pEmptyPlace, FullPlace* pFullPlace);
        void attach(IObserver* pObserver) override;
        void dettach() override; 
        void notify() override;
        void addMachine(Machine* pMachine){ this->listMachine.push_back(pMachine); };
        int getBottleCounter(){ return this->bottleCounter; };
        void addBottleCounter(){ this->bottleCounter++; };

        EmptyPlace* getEmptyPlace(){ return this->emptyPlace; };
        FullPlace* getFullPlace(){ return this->fullPlace; };
        Machine& getMachine(int pIndex);
        int getMachineSize(){ return this->listMachine.size(); };
};

void ControlSystem::attach(IObserver* pObserver){
    this->observer = observer;
}

void ControlSystem::dettach(){
    delete this->observer; 
}

void ControlSystem::notify(){}

ControlSystem::ControlSystem(EmptyPlace* pEmptyPlace, FullPlace* pFullPlace){
    this->emptyPlace = pEmptyPlace;
    this->fullPlace = pFullPlace;
    bottleCounter = 0;
}

Machine& ControlSystem::getMachine(int pIndex){
    Machine* machine;
    for (int i = 0; i < this->listMachine.size(); i++){
        if(pIndex == i)
            return *this->listMachine[i];
    }
    return *machine;
}

#endif //CONTROL_SYSTEM_HPP