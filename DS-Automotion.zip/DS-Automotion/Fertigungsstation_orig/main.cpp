#include <iostream>
#include "Simulator.hpp"




using namespace std;

int main(){
    Simulator* simulator = new Simulator();
    simulator->initTest();
    simulator->runTest();

    return 0;
}