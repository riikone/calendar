
#include 'vector';
#include 'observer.hpp';

using namespace std;

class Machine : public ISubject{
    private:
        vector<class IOberserver*> listObserver;
        int status;
        string name;

    public:
        void attach(IObserver* observer){ this.listObserver.push_back(observer); };
        void dettach(IObserver* observer){ this.listObserver.erase(std::remove(this.listObserver.begin(), this.listObserver.end(), observer), this.listObserver.end()); };
        void virtual noify();

        //Getter and Setter
        int getStatus() { return this.status; };
        void setStatus(int value) { this.status = value; notify();};
        string getName() { return this.name; };
        void setName(string name) { this.name = name; };

        string startTimer(unsigned short int seconds, callback);
        void killTimer(string id);
}

Machine::notify(){
    std::vector<IOberserver>::iterator it;
    for(it = this.listObserver.begin(); it = this.listObserver.end(); ++it){
        it->onMachineSensorChanged();
    }
}

