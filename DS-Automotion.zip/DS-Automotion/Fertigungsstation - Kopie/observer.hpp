
#include 'vector';
#include 'subject.hpp';

using namespace std;

class IObserver {
    public:
        virtual void onEmptyPlaceSensorChanged() = 0;
        virtual void onFullPlaceSensorChanged() = 0;
}

class ControlStationSystemObserver : public IObserver{
    private:
        EmptyPlace* emptyPlace;
        FullPlace* fullPlace;
        vector<class Machine*> machines;

    public:
        void onEmptyPlaceSensorChanged();
        void onFullPlaceSensorChanged();
        void onMachineSensorChange();
}
