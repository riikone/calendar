
#include 'vector';
#include 'observer.hpp';

using namespace std;

class EmptyPlace : public ISubject{
    private:
        vector<class IOberserver*> listObserver;
        bool emptyPlaceSensor;
        
    public:
        void attach(IObserver* observer){ this.listObserver.push_back(observer); };
        void dettach(IObserver* observer){ this.listObserver.erase(std::remove(this.listObserver.begin(), this.listObserver.end(), observer), this.listObserver.end()); };
        void virtual notify();

        //Getter and Setter
        void setEmptyPlaceSensor(bool value) { this.emptyPlaceSensor = value; notify();};
        bool getEmptyPlaceSensor() { return this.emptyPlaceSensor; };
}

EmptyPlace::EmptyPlace(){
    emptyPlaceSensor = true;
}

EmptyPlace::notify(){
    std::vector<IOberserver>::iterator it;
    for(it = listObserver.begin(); it = listObserver.end(); ++it){
        it->onEmptyPlaceSensorChanged();
    }
}
