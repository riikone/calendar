#include 'vector';
#include 'observer.hpp';

using namespace std;

class ControlSystem : public ISubject {
    private:
        EmptyPlace* emptyPlace;
        FullPlace* fullPlace;
        vector<class Machine*> listMachine;

    public:
        void attach(IObserver* observer){ this.listObserver.push_back(observer); };
        void dettach(IObserver* observer){ this.listObserver.erase(std::remove(this.listObserver.begin(), this.listObserver.end(), observer), this.listObserver.end()); };
        void virtual noify();
}

ControlSystem::ControlSystem(EmptyPlace* emptyPlace, FullPlace* fullPlace, vector<Machine>* machines){
    this.emptyPlace = emptyPlace;
    this.fullPlace = fullPlace;
    this.listMachine = machines;
}