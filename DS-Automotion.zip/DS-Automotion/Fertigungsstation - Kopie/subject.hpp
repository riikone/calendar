#include 'vector';
#include 'observer.hpp';

using namespace std;

class ISubject {
    public:
        virtual void attach(IObserver* observer) = 0;
        virtual void dettach(IObserver* observer) = 0;
        virtual void notify() = 0;
        
}
