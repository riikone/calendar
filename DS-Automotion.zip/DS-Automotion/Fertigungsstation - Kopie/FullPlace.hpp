
#include 'vector';
#include 'observer.hpp';

using namespace std;

class FullPlace : public ISubject{
    private:
        vector<class IOberserver*> listObserver;
        bool fullPlaceSensor;

    public:
        void attach(IObserver* observer){ this.listObserver.push_back(observer); };
        void dettach(IObserver* observer){ this.listObserver.erase(std::remove(this.listObserver.begin(), this.listObserver.end(), observer), this.listObserver.end()); };
        void virtual notify();

        //Getter and Setter
        void setFullPlaceSensor(bool value){ this.fullPlaceSensor = value; notify(); };
        bool getFullPlaceSensor() { return this.fullPlaceSensor; };
}

FullPlace::notify(){
    std::vector<IOberserver>::iterator it;
    for(it = this.listObserver.begin(); it = this.listObserver.end(); ++it){
        it->onFullPlaceSensorChanged();
    }
}
